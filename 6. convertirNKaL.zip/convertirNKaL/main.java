package convertirNKaL;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc = new Scanner(System.in);
		
		double libras, kilogramos, kg= 2.2046, lb= 2.204;
		
		System.out.println("este programa pasa de kiloogramos a libras y libras a kilogramos");
		System.out.println("1. pasa de kilogramos a libras");
		System.out.println("2. pasa de libras a kilogramos");
		int opcion = tc.nextInt();
		
		switch (opcion) {
		case 1:
			System.out.println("ingresa la cantidad de kilogreamos");
			kilogramos = tc.nextDouble();
			
			libras = kilogramos * kg;
			
			System.out.println("los kilogramos en libras son: " +libras);
			
			break;
		case 2:
			
			System.out.println("ingres la cantidad de libras");
			libras = tc.nextDouble();
			
			kilogramos = libras / lb; 
			System.out.println("las libras a kilogramos son: " +kilogramos);
			
			break;
		default:
			break;
		}
		
		
		

	}

}
