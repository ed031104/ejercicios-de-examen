package Convertidorde_Y_P_PaCM;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner tc = new Scanner(System.in);
			
System.out.println("Este programa pasa de yardas a CM, de pies a CM, de pulgadas a CM");

System.out.println("ingresa un opcion.");
System.out.println("1. pasa de yardas a CM");
System.out.println("2. pasa de pies a CM");
System.out.println("3. pasa de pulgadas a CM");
int opcion = tc.nextInt();
switch (opcion) {
case 1:
	System.out.println("pasa de yardas a cm");
	double yardas, CM= 91.44 , resultado;
	System.out.println("ingresa la cantidad de yardas");
	yardas = tc.nextDouble();
	resultado= yardas * CM;
	System.out.println("el reultado es: " +resultado+ "cm" );
	break;
	
case 2:
	System.out.println("pasa de pies a cm");
	double pies, cm= 30.48 , r;
	System.out.println("ingresa la cantidad de pies:");
	pies = tc.nextDouble();
	r= pies * cm;
	System.out.println("el reultado es: " +r+ "cm" );
	
	
	break;
	
case 3:
	System.out.println("pasa de pulgadas a cm");
	double pulgadas, Cm= 2.54 , re;
	System.out.println("ingresa la cantidad de pulgadas:");
	pulgadas = tc.nextDouble();
	r= pulgadas * Cm;
	System.out.println("el reultado es: " +r+ "cm" );
	
	
	
	
break;

default:
	break;
}


	}

}
