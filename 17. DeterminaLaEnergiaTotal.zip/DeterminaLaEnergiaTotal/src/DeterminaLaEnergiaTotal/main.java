package DeterminaLaEnergiaTotal;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Scanner tc = new Scanner(System.in);
		System.out.println("determina la energia total.");
		System.out.println("para determinarla hay que encontrar primero la energia cinetica y energia potencial");
		
		System.out.println("1. determina la energia cinetica");
		System.out.println("ingresa la masa:");
		double masa = tc.nextDouble();
		System.out.println("ingresa la velocidad:");
		double velocidad= tc.nextDouble();
		
		double Ec= ( masa * (velocidad*velocidad) /2 );
		
		System.out.println("La energia cinetica es: " +Ec+ " j");
		
		System.out.println("2. determina la energia potencial.");
		System.out.println("ingresa la masa");
		double m = tc.nextDouble();
		System.out.println("ingresa la altura");
		double h = tc.nextDouble();
		double g = 9.81;
		
		double Ep = m*g*h;
		System.out.println("La energia potencial es: " +Ep+ " j");
		
		
		double Et= Ec + Ep ;
		System.out.println("la energia total es:" +Et+ "j");
		
		
	}

}
