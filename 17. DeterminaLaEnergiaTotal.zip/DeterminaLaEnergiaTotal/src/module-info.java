/**
 * 
 */
/**
 * @author edwin
 *
 */
module DeterminaLaEnergiaTotal {
}