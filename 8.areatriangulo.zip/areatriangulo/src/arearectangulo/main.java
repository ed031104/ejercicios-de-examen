package arearectangulo;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner teclado = new Scanner(System.in);
		
		double primerl , segundol, tercerl, perimetro, sp;
		int resultado;
		System.out.println("ingrse el primer lado");
		primerl = teclado.nextInt();
	
			
		    
		System.out.println("ingrese el segundo lado");
		segundol = teclado.nextInt(); 
		
		
		System.out.println("ingrese el tercer lado");
		tercerl = teclado.nextInt(); 
		if (primerl <= 0 || segundol <= 0 || tercerl <= 0 ) {
			System.out.println("no se pueden ocupar numeros menores a 0");
		}
		else {
        perimetro = primerl+ segundol + tercerl;	
		sp = perimetro / 2;
		double area = Math.sqrt( sp *(sp-primerl)*(sp-segundol) * (sp-tercerl) );
		
		System.out.println("el area es " + area);
		}
	}

}
