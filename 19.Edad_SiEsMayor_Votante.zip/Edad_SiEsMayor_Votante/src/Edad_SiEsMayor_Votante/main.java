package Edad_SiEsMayor_Votante;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner tc = new Scanner(System.in);
		System.out.println("ingresa tu edad");
		int edad = tc.nextInt();
		if (edad >= 16 ) {
			System.out.println("es vontante dado que tiene 16 o mas");
		}
		else {
			
		}
		
		
		
		
		
		
		
		
	}

}
