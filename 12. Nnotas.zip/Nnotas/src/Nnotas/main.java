package Nnotas;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc = new Scanner(System.in);
		System.out.println("Ingrese el número de notas a promediar:");
        int n = tc.nextInt();
        double[] notas = new double[n];
        double suma = 0;

        for (int i = 0; i < n; i++)
        {
          System.out.println("Ingrese la nota " + (i + 1) + ":");
            notas[i] = tc.nextDouble();
            suma += notas[i];
        }

        double promedio = suma / n;
       System.out.println("El promedio de las " + n + " notas ingresadas es: " + promedio);
		
		
		
		

	}

}
