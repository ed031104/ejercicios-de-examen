package calculadoradeareayperimetrodecirculo;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		   Scanner teclado = new Scanner(System.in);
           
           
           
			double perimetro, area, pi = 3.1416;
			
			
			System.out.println("elige una opcion");
			System.out.println("1. calcula el area de un circulo");
            System.out.println("2. calcula el perimetro de un circulo ");
            
            int opcion;
			opcion = teclado.nextInt();
			
			
			switch (opcion) {
			
			case 1:
				
			double radio;
				
			System.out.println("ingrese el radio");
				radio = teclado.nextDouble();
				area = pi* radio *radio;
				System.out.println("el area es: " + area);
				break;
			
			case 2:
				
				double ra;
				System.out.println("ingrese el radio");
				ra = teclado.nextDouble();
				perimetro = 2 * pi *ra;
				System.out.println("el area es: " + perimetro);
			default:
				break;
			}

	}

}
