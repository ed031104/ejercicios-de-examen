package evaluaunafuncion;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		     Scanner tc = new Scanner(System.in);
               double Fy,x=1, X;
               System.out.println("evalua funcion");
               System.out.println("ingresa una opcion");
               System.out.println("1. evalua la funcion con x=1 ");
               System.out.println("2. evalua la funcion");
               int opcion=tc.nextInt();
               switch (opcion) {
			case 1:
				System.out.println("el valor de la funcion es: ");
               Fy=  Math.pow(5*x, 4) + Math.pow(2*x, 3) + Math.pow(3*x, 2) + 7;
				System.out.println("el resultado de la funcion es: " +Fy);
				break;
			case 2:
				System.out.println("ingresa el valor de X");
				X = tc.nextDouble();
				
	            Fy=  (double)(Math.pow(5*X, 4)) + (double)(Math.pow(2*X, 3)) + (double)(Math.pow(3*X, 2)) + 7;
				System.out.println("el resultado de la funcion es " +Fy);
				break;
			default:
				break;
			}
               
               
	}

}
