package arearectangulo;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner teclado = new Scanner(System.in);
		
		int area, base , altura;
		int resultado;
		System.out.println("ingrse la base");
		base = teclado.nextInt();
		if (base < 0 || base <= 0) 
		{
			System.out.println("no se pueden ocupar numeros menores a 0");
		}	    
		System.out.println("ingrese la altura");
		altura = teclado.nextInt(); 
		if (altura < 0 || altura <= 0)
		{
			System.out.println("no se pueden ocupar numeros menores a 0");

		}	
		
	
		area = base * altura;
		resultado = area;
		if (area < 0 || area <= 0) {
			System.out.println("el area no puede ser menor a 0");

		}
		else 	
			
		System.out.println("el area es " + resultado);

	}

}
