/**
 * 
 */
/**
 * @author edwin
 *
 */
module arearectangulo {
}