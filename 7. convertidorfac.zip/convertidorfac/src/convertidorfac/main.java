package convertidorfac;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc = new Scanner(System.in);
		
		double Fahrenheit , celsius, resultado ;
		
		System.out.println("este programa pasa de Fahrenheit a Celsius y celsius a Fahrenheit");
		System.out.println("1. pasa de Fahrenheit a Celsius");
		System.out.println("2. pasa de celsius a Fahrenheit");
		int opcion = tc.nextInt();
		
		switch (opcion) {
		case 1:
			System.out.println("ingresa la cantidad de Fahrenheit");
			Fahrenheit = tc.nextDouble();
			
			 celsius= (Fahrenheit - 32) * 5/9;
			
			System.out.println("el resultado en celsius es: " +celsius);
			
			break;
		case 2:
			
			System.out.println("ingres la cantidad de celsius");
			celsius = tc.nextDouble();
			
			Fahrenheit = (celsius * 9/5) +32; 
			System.out.println("el resultado en fahrenheit es: " +Fahrenheit);
			
			break;
		default:
			break;
		
		

	}
		
   }
}
