package Fuerza;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner tc = new Scanner(System.in);
		double masa, aceleracion;
		
		System.out.println("este programa calcula la fuerza de un cun cuerpo");
		
		System.out.println("ingresa la masa del cuerpo");
		masa = tc.nextDouble();
		
		System.out.println("ingresa la aceleracion del cuerpo");
		aceleracion = tc.nextDouble();
		
		double fuerza = masa * aceleracion ;
		
		System.out.println("la fuerza del cuerpo es: " +fuerza + " N ");
		
		
		
		
		
 
	}

}
