/**
 * 
 */
/**
 * @author edwin
 *
 */
module DeterminanteDelSegundoBien {
}