package DeterminanteDelSegundoBien;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
	      int[][] matriz = new int[2][2];
	      
	      // Pedimos al usuario que ingrese los valores de la matriz
	      System.out.println("Ingrese los valores de la matriz de segundo orden (2x2):");
	      for (int i = 0; i < 2; i++) {
	         for (int j = 0; j < 2; j++) {
	            matriz[i][j] = scanner.nextInt();
	         }
	      }
	      
	      // Calculamos el determinante
	      int determinante = matriz[0][0] * matriz[1][1] - matriz[0][1] * matriz[1][0];
	      
	      // Mostramos el resultado
	      System.out.println("El determinante de la matriz es: " + determinante);
	}

}
