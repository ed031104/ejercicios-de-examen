package calculaelfactorialdeunnumero;

import java.util.Scanner;
import java.util.StringTokenizer;

public class main {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		
		
		
		Scanner tc = new Scanner(System.in);
			
			int n,factorial=1 ;
			
			do {
			
				System.out.println("ingrese la factorial");
			      n = tc.nextInt();
			}while(n<0); 
				
				
			
		
			for(int i=1; i<=n; i++) {  
			factorial = factorial * i;
			
		
			
			}
			System.out.println("el resultado de el factorial es:" +factorial);
			
			
			

			  
		
	}

}
