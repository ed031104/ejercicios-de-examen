/**
 * 
 */
/**
 * @author edwin
 *
 */
module calculaelfactorialdeunnumero {
}