package EcuacionLIneal;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner tc = new Scanner(System.in);
		
		double x ,a ,b;
		
		System.out.println("ingrese el valor de a");
	    a =tc.nextDouble();
		
	    System.out.println("ingrese el valor de b");
		b = tc.nextDouble();
		
		if(a<=0 || b<=0) {
			System.out.println("solo se pueden ocupar numeros reales");
		}
		else {
		x=-b/a;
		
		System.out.println("la respuesta de la ecuacion ax+b=0 es: " +x);
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
