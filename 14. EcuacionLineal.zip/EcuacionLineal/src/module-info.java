/**
 * 
 */
/**
 * @author edwin
 *
 */
module EcuacionLineal {
}