package Coseno;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
         Scanner sc = new Scanner(System.in);
         
         System.out.print("Introduce un número: ");
         double num =sc.nextDouble();
         num = Math.toRadians(num);
         double coseno = Math.cos(num);
         
         System.out.println("El coseno de es: " + coseno);
	}

}
