/**
 * 
 */
/**
 * @author edwin
 *
 */
module Coseno {
}