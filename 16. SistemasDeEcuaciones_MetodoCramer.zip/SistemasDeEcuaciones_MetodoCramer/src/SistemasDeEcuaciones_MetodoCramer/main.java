package SistemasDeEcuaciones_MetodoCramer;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
         Scanner tc = new Scanner(System.in);
         int a,valorx,b,valory,c, valors; 
         System.out.println("determinar el valor de la ecucion |ax+by=c|");
         System.out.println("                                  |dx+ey=f|");
         
	     System.out.println("ingresa el valor de a");  
		 a = tc.nextInt(); 
		 System.out.println("ingresa el valor de b");
		 b = tc.nextInt();
		 System.out.println("ingresa el valor de c");
		 c = tc.nextInt();
		 System.out.println("ingresa el valor de d");
		 int d = tc.nextInt(); 
		 System.out.println("ingresa el valor de e");
		 int e = tc.nextInt();
		 System.out.println("ingresa el valor de f");
		 int f = tc.nextInt();
		
		 System.out.println("el valor de la ecuacion es |"+a+"x+"+b+""+"y="+c+"|");
		 System.out.println("                           |"+d+"x+"+e+""+"y="+f+"|");
		
		
		valorx = (c*e)-(b*f);
		valory = (a*f)-(c*d);
		valors = (a*e)-(b*d);
		
		int x = valorx/valors;
		int y = valory/valors;
		
		System.out.println("el valor de x en la ecuacion es" +x); System.out.println("el valor de y en la ecuacion es" +y);
		
	}

}
