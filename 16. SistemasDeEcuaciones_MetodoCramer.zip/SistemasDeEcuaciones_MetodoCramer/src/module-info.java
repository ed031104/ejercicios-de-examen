/**
 * 
 */
/**
 * @author edwin
 *
 */
module SistemasDeEcuaciones_MetodoCramer {
}