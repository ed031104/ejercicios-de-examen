package determinaelvalordey;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	   Scanner tc = new Scanner(System.in);
		
	   double y,x, c= 2.5; 
	   int opcion = 0;
	   int X=2;
	   System.out.println("ingresa una opcion");
	   
	   System.out.println("1. para resolver la ecuacion con el valor de x=2");
	   System.out.println("2. tu defines el valor de x ");
	   opcion=tc.nextInt();
	   switch (opcion) {
	case 1:
		System.out.println("el valor de x es 2");
		y= X*c-2;
		System.out.println("el resultado es: " +y);
		break;
		
	case 2:
		System.out.println("ingrese el valor de x");
		x= tc.nextInt();
		
		y= x*c-2;
		System.out.println("el valor de x es: " +y);
		
		break;

	default:
		break;
	}
	   
	   
	   
		

	}

}
