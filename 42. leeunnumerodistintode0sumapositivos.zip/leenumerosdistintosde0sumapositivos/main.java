package leenumerosdistintosde0sumapositivos;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
          
		Scanner tc = new Scanner(System.in);
		
		System.out.print("Ingrese la cantidad de números a leer: ");
        int n =tc.nextInt();

        int sumPositive = 0;
        int countNegative = 0;

        for (int i = 0; i < n; i++) {
            System.out.print("Ingrese el número " + (i + 1) + ": ");
            int number = tc.nextInt();

            if (number > 0) {
                sumPositive += number;
            } else {
                countNegative++;
            }
        }

        System.out.println("La suma de los números positivos es: " + sumPositive);
        System.out.println("La cantidad de números negativos es: " + countNegative);

        tc.close();
		
		
		
	}

}
