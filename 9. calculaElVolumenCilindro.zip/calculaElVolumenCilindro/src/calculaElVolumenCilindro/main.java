package calculaElVolumenCilindro;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner tc = new Scanner(System.in); 
		System.out.println("Este programa calcula el volumen de un cilindro");
		
		System.out.println("ingrese el radio del cilindro");
		double radio = tc.nextDouble();
		
		if(radio <= 0) {
			System.out.println("no ingres numeros menores a 0!!");
		}
		System.out.println("ingresa la altura del cilindro ");
		double altura = tc.nextDouble();
		if(altura <= 0) {
			System.out.println("no ingres numeros menores a 0!!");
		}
		else {
		double pi= 3.1416, volumen;
		
		volumen = pi * (radio * radio) * altura;
		System.out.println("el volumen del cilindro es: " +volumen);
		}
		
		
		
	}

}
