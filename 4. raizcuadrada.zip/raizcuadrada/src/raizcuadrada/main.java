package raizcuadrada;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc = new Scanner(System.in);
		
		System.out.println("ingresa un numero");
		double numero = tc.nextInt();
		
		double raizCuadrada = Math.sqrt(numero);
		System.out.printf("Raiz cuadrada de es: " +raizCuadrada);
		
	}

}
